#include <stdio.h>
#include <stdlib.h>
#include "utilisateur.h"

int main()
{
    Administrateur();
    return 0;
}
